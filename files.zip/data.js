/* =========================================================
   DATA — In de voetsporen van Jean de La Fontaine
   Alle inhoud: verhalen, quizzen, vocabulaire, escaperooms
   ========================================================= */

const AVATARS = ["🧑‍🎓","👩‍🎓","🦊","🐺","🐢","🐇","🦁","🐦‍⬛","🦉","🐭","🐸","🕊️","👑","🎭","🖋️","🌟"];

const BADGES = {
  b1:{name:"Vriend van Jean", icon:"🤝"},
  b2:{name:"Hofgeleerde",     icon:"👑"},
  b3:{name:"Fabelkenner",     icon:"📖"},
  b4:{name:"Leerling-schrijver",icon:"✍️"},
  b5:{name:"Fabelmaker",      icon:"🪶"},
  b6:{name:"Meester van de Moraal", icon:"🏛️"}
};

/* Inspiratiekaarten voor de fabel (H5) */
const INSPIRE_ANIMALS = [
  {emoji:"🦊", nl:"vos",   fr:"le renard",  trait:"sluw / rusé"},
  {emoji:"🐺", nl:"wolf",  fr:"le loup",    trait:"hebzuchtig / avide"},
  {emoji:"🐢", nl:"schildpad", fr:"la tortue", trait:"geduldig / patient"},
  {emoji:"🐇", nl:"haas",  fr:"le lièvre",  trait:"snel / rapide"},
  {emoji:"🦁", nl:"leeuw", fr:"le lion",    trait:"trots / fier"},
  {emoji:"🐜", nl:"mier",  fr:"la fourmi",  trait:"vlijtig / travailleur"},
  {emoji:"🦗", nl:"krekel",fr:"la cigale",  trait:"zorgeloos / insouciant"},
  {emoji:"🐦‍⬛", nl:"raaf", fr:"le corbeau", trait:"ijdel / vaniteux"},
  {emoji:"🐭", nl:"muis",  fr:"la souris",  trait:"klein maar slim / petit"},
  {emoji:"🦉", nl:"uil",   fr:"le hibou",   trait:"wijs / sage"}
];

const MORALS_FR = [
  {fr:"Rien ne sert de courir ; il faut partir à point.", nl:"Hard rennen heeft geen zin; je moet op tijd vertrekken."},
  {fr:"Tel est pris qui croyait prendre.", nl:"Wie een ander wil beetnemen, wordt zelf beetgenomen."},
  {fr:"La raison du plus fort est toujours la meilleure.", nl:"Het recht van de sterkste geldt altijd."},
  {fr:"Apprenez que tout flatteur vit aux dépens de celui qui l'écoute.", nl:"Wie vleit, leeft ten koste van wie luistert."}
];

const CHAPTERS = [
  /* ================= HOOFDSTUK 1 ================= */
  {
    id:"ch1", num:1, badge:"b1",
    title:"Ontmoet Jean",
    subtitle:"Wie was Jean de La Fontaine?",
    emoji:"🪶",
    goal:"Maak kennis met Jean de La Fontaine en zijn leven.",
    steps:[
      {
        type:"narrative", title:"Bienvenue!",
        jean:[
          "Ah, daar ben je! Ik ben <strong>Jean de La Fontaine</strong>, geboren in het jaar 1621 in het stadje <em>Château-Thierry</em>, in de streek Champagne.",
          "Ik werd de beroemdste <em>fabuliste</em> — fabelschrijver — van Frankrijk. Kom mee, dan leer ik je alles over mijn leven, mijn tijd en de kunst van de fabel.",
          "Aan het einde van elke reis wacht een <strong>schrijfkist</strong> vol geheimen. Verzamel <strong>veren (plumes)</strong> en <strong>badges</strong> om die te openen. On y va — daar gaan we!"
        ]
      },
      {
        type:"tour", title:"Belevenis — In de voetsporen van Jean",
        intro:"Voordat je aan de opdrachten begint: loop mee in de voetsporen van Jean. Bezoek zijn geboortestad, zijn huis en de plekken die zijn leven bepaalden. Klik op ▶ Volgende.",
        rooms:[
          {
            img:"img/chateauthierry.jpg", name:"1. Château-Thierry — waar het begon", fr:"la ville de Château-Thierry",
            text:"Welkom in <strong>Château-Thierry</strong>, het stadje in de streek Champagne waar Jean in <strong>1621</strong> werd geboren. Dit is de <em>Porte Saint-Pierre</em>, een oude stadspoort uit de middeleeuwen. Als kind liep Jean door deze straten.",
            fact:"Château-Thierry ligt zo'n 95 km ten oosten van Parijs."
          },
          {
            img:"img/geboortehuis.jpg", name:"2. Het geboortehuis van Jean", fr:"la maison natale",
            text:"Dit deftige huis is het <strong>geboortehuis</strong> van Jean de La Fontaine. Zijn vader was een belangrijke ambtenaar (opzichter van de wateren en bossen). Vandaag is het een <strong>museum</strong> over Jeans leven en zijn fabels.",
            fact:"Je kunt het Musée Jean de La Fontaine er nu nog steeds bezoeken."
          },
          {
            img:"img/champagne.jpg", name:"3. De streek Champagne", fr:"la Champagne",
            text:"Rondom Château-Thierry strekken de <strong>wijngaarden van de Champagne</strong> zich uit. Tussen deze glooiende heuvels, bossen en rivieren groeide Jean op. De natuur en de dieren die hij hier zag, komen terug in zijn fabels.",
            fact:"Uit deze streek komt ook de beroemde mousserende wijn: champagne."
          },
          {
            img:"img/academie.jpg", name:"4. De Académie française", fr:"l'Académie française",
            text:"Jean vertrok naar <strong>Parijs</strong> om schrijver te worden en zocht een <em>mécène</em> (beschermheer). Zijn talent werd beloond: in <strong>1684</strong> werd hij lid van de <strong>Académie française</strong>, het genootschap dat waakt over de Franse taal. Een grotere eer bestond er niet.",
            fact:"De Académie française bestaat nog steeds en heeft precies 40 leden, 'de onsterfelijken' genoemd."
          },
          {
            img:"img/fablesboek.jpg", name:"5. De beroemde Fables", fr:"les Fables",
            text:"In <strong>1668</strong> verschenen Jeans <strong>Fables</strong>. Hier zie je een gravure van « <em>Le Corbeau et le Renard</em> »: de raaf in de boom en de sluwe vos eronder. Met dieren als personages leerde Jean de mensen wijze lessen.",
            fact:"Deze gravure is van Gustave Doré, een beroemde 19e-eeuwse illustrator."
          },
          {
            img:"img/standbeeld.jpg", name:"6. Voor altijd geëerd", fr:"le monument",
            text:"Jean stierf in <strong>1695</strong>, maar wordt nog steeds geëerd. In heel Frankrijk staan <strong>standbeelden</strong> voor hem, vaak met zijn fabeldieren zoals de vos en de leeuw eromheen. Zijn fabels worden nog altijd op school gelezen — ook door jou!",
            fact:"Dit monument voor La Fontaine stond rond 1900 in Parijs."
          }
        ]
      },
      {
        type:"quiz", title:"Interactieve quiz — Het leven van Jean",
        intro:"Lees goed en kies het juiste antwoord. Elk goed antwoord levert een veer op!",
        questions:[
          {q:"In welk jaar werd Jean de La Fontaine geboren?",
           options:["1521","1621","1721","1665"], answer:1,
           explain:"Jean werd geboren in 1621, aan het begin van de 17e eeuw."},
          {q:"In welke Franse stad werd hij geboren?",
           options:["Parijs","Lyon","Château-Thierry","Versailles"], answer:2,
           explain:"Hij werd geboren in Château-Thierry in de streek Champagne."},
          {q:"Waar is Jean vooral beroemd om geworden?",
           options:["Zijn schilderijen","Zijn fabels (fables)","Zijn oorlogen","Zijn kastelen"], answer:1,
           explain:"Zijn 'Fables' maakten hem wereldberoemd. Een fabel = une fable."},
          {q:"Welke opleiding volgde Jean eerst?",
           options:["Geneeskunde","Rechten (jura)","Sterrenkunde","Muziek"], answer:1,
           explain:"Jean studeerde eerst rechten voordat hij zich op de literatuur richtte."},
          {q:"Wie inspireerde La Fontaine met oude fabels?",
           options:["Napoleon","De Griek Ésope (Aesopus)","Julius Caesar","Molière"], answer:1,
           explain:"De oude Griek Ésope (Aesopus) schreef al fabels; La Fontaine gaf ze nieuw leven."}
        ],
        challenge:[
          {q:"In welke eeuw leefde Jean de La Fontaine grotendeels?", options:["De 17e eeuw","De 15e eeuw","De 19e eeuw"], answer:0, explain:"Geboren 1621, gestorven 1695 — de 17e eeuw (le XVIIe siècle)."},
          {q:"Wat is een 'fabuliste'?", options:["Een fabelschrijver","Een schilder","Een soldaat"], answer:0, explain:"« un fabuliste » = een fabelschrijver, zoals La Fontaine."}
        ]
      },
      {
        type:"order", title:"Sleepopdracht — De tijdlijn van Jean",
        intro:"Sleep de gebeurtenissen in de juiste volgorde, van vroeg naar laat.",
        items:[
          {year:"1621", label:"Jean wordt geboren in Château-Thierry"},
          {year:"1641", label:"Hij begint met studeren (o.a. rechten)"},
          {year:"1658", label:"Hij werkt voor beschermheer Nicolas Fouquet"},
          {year:"1668", label:"Zijn eerste bundel 'Fables' verschijnt"},
          {year:"1684", label:"Hij wordt lid van de Académie française"},
          {year:"1695", label:"Jean de La Fontaine overlijdt in Parijs"}
        ]
      },
      {
        type:"escape", title:"Escaperoom — De oude schrijfkist",
        story:"Voor je staat een stoffige, vergrendelde schrijfkist van Jean. De kist opent alleen als je vijf vragen over zijn leven goed beantwoordt. <strong>Lees eerst zijn levensbrief hieronder</strong> — daarin staan alle antwoorden verstopt. Elke goed beantwoorde aanwijzing geeft je één <strong>letter</strong>. Los daarna het slot op.",
        reading:"<strong>📜 Uit de levensbrief van Jean de La Fontaine:</strong><br><br>« Ik kwam ter wereld in het jaar <em>1621</em>, in het stadje <em>Château-Thierry</em> in de streek Champagne. Mijn vader wilde dat ik <em>rechten</em> (la Loi) zou studeren, en dat deed ik gehoorzaam. Maar mijn hart lag altijd bij de verhalen. De oude Griek <em>Ésope</em> (Aesopus) had eeuwen vóór mij al fabels geschreven; ík gaf ze nieuw leven in het Frans. In <em>1668</em> verscheen mijn eerste bundel <em>Fables</em>. En in <em>1684</em> werd ik gekozen tot lid van de <em>Académie française</em> — de hoogste eer die een Frans schrijver kan krijgen. »",
        clues:[
          {ico:"📜", label:"Aanwijzing 1 — De geboorte", symbol:"P",
           question:"In welk jaar en in welke stad werd Jean geboren?",
           options:["1521 in Parijs","1621 in Château-Thierry","1665 in Versailles","1621 in Lyon"], answer:1,
           explain:"Juist — in 1621, te Château-Thierry in de streek Champagne. Je verdient de letter P."},
          {ico:"⚖️", label:"Aanwijzing 2 — De studie", symbol:"L",
           question:"Welke studie volgde Jean op wens van zijn vader?",
           options:["Geneeskunde","Rechten (la Loi)","Sterrenkunde","Theologie"], answer:1,
           explain:"Klopt — hij studeerde eerst rechten (la Loi). Daarom de letter L."},
          {ico:"🏺", label:"Aanwijzing 3 — De inspiratie", symbol:"U",
           question:"Welke oude Griek inspireerde Jean met zijn fabels?",
           options:["Homerus","Ésope (Aesopus)","Plato","Sokrates"], answer:1,
           explain:"Precies — Ésope schreef de eerste fabels. La Fontaine gaf ze nieuw leven. Letter: U."},
          {ico:"📚", label:"Aanwijzing 4 — De eerste bundel", symbol:"M",
           question:"In welk jaar verscheen Jeans eerste bundel 'Fables'?",
           options:["1621","1643","1668","1695"], answer:2,
           explain:"Juist — de eerste 'Fables' verschenen in 1668. De letter M is van jou."},
          {ico:"🏛️", label:"Aanwijzing 5 — De grote eer", symbol:"E",
           question:"Van welk beroemd gezelschap werd Jean in 1684 lid?",
           options:["De Académie française","Het leger van de koning","De Sorbonne-universiteit","Het parlement van Parijs"], answer:0,
           explain:"Correct — de Académie française, de hoogste eer voor een schrijver. Je laatste letter: E."}
        ],
        code:"PLUME", codeHint:"Vijf letters. Het Franse woord voor de 'veer' waarmee Jean schreef — en tegelijk voor een pen.",
        success:"De kist klikt open! Binnenin ligt een gouden ganzenveer. Je bent nu een echte Vriend van Jean."
      }
    ]
  },

  /* ================= HOOFDSTUK 2 ================= */
  {
    id:"ch2", num:2, badge:"b2",
    title:"Het hof van de Zonnekoning",
    subtitle:"Frankrijk in de 17e eeuw",
    emoji:"👑",
    goal:"Begrijp de historische context: het Frankrijk van Lodewijk XIV.",
    steps:[
      {
        type:"narrative", title:"Le Roi-Soleil",
        jean:[
          "In mijn tijd regeerde <strong>Lodewijk XIV</strong> (Louis Quatorze), bijgenaamd <em>le Roi-Soleil</em> — de <strong>Zonnekoning</strong>. Bekijk hieronder zijn echte staatsieportret.",
          "Hij bouwde het immense <strong>Château de Versailles</strong>, waar het hof leefde in weelde: spiegels, tuinen, bals en intriges.",
          "Kunstenaars en schrijvers zochten de gunst van de koning. Loop met mij mee door het échte Versailles en ontdek de geheimen van het hof."
        ],
        images:[
          {src:"img/louis14.jpg", cap:"Lodewijk XIV, 'le Roi-Soleil' — staatsieportret door Hyacinthe Rigaud (1701)."},
          {src:"img/versailles.jpg", cap:"Het echte Château de Versailles: de Cour de Marbre (marmeren binnenplaats)."}
        ]
      },
      {
        type:"tour", title:"Belevenis — Loop mee met de Zonnekoning",
        intro:"Stap in de 17e eeuw. Volg Lodewijk XIV door de échte zalen van Versailles — en ontdek daarna hoe anders het leven van de gewone burger eruitzag. Klik op ▶ Volgende om verder te lopen.",
        rooms:[
          {
            img:"img/versailles.jpg", name:"1. De Cour de Marbre", fr:"la Cour de Marbre",
            text:"Je staat op de <strong>marmeren binnenplaats</strong>. Elke dag verdrongen honderden hovelingen (<em>les courtisans</em>) zich hier, hopend op één blik van de koning. Alleen wie rijk en van adel was, mocht dichterbij komen.",
            fact:"Wist je dat? Aan het hof leefden zo'n 3.000 tot 10.000 mensen rond de koning."
          },
          {
            img:"img/hall_of_mirrors.jpg", name:"2. De Spiegelzaal", fr:"la galerie des Glaces",
            text:"De koning loopt voor je uit door de <strong>Spiegelzaal</strong>. Maar liefst <strong>357 spiegels</strong> weerkaatsen het licht van duizenden kaarsen. Hier ontving Lodewijk XIV ambassadeurs uit de hele wereld — alles moest zijn macht en rijkdom laten zien.",
            fact:"Spiegels waren toen enorm duur. Een hele zaal vol spiegels was pure show van rijkdom."
          },
          {
            img:"img/chambre_roi.jpg", name:"3. De slaapkamer van de koning", fr:"la chambre du roi",
            text:"Elke ochtend was er <em>le lever du roi</em>: uitgekozen edelen mochten toekijken hoe de koning wakker werd en werd aangekleed. Wie hem zijn hemd mocht aangeven, had groot aanzien. Zelfs opstaan was hier een <strong>openbaar schouwspel</strong>.",
            fact:"De koning at ook vaak in het openbaar: het hof keek toe hoe hij zijn maaltijd nuttigde."
          },
          {
            img:"img/jardins.jpg", name:"4. De tuinen", fr:"les jardins",
            text:"In de eindeloze <strong>tuinen</strong> van tuinarchitect André Le Nôtre wandelde het hof tussen fonteinen en perfect geknipte hagen. 's Avonds waren er feesten, muziek en vuurwerk. Zelfs de natuur moest buigen voor de wil van de koning.",
            fact:"De tuinen zijn zó groot dat je er kilometers in kunt wandelen — met honderden fonteinen."
          },
          {
            img:"img/paysans.jpg", name:"5. Buiten de poorten: de gewone burger", fr:"le paysan / le peuple",
            text:"Maar buiten de vergulde poorten was het leven héél anders. De gewone burger — vooral de <strong>boer</strong> (<em>le paysan</em>) — werkte hard op het land en betaalde zware <strong>belastingen</strong> om de weelde van het hof te betalen. Veel gezinnen leefden in armoede, in kleine, donkere huizen.",
            fact:"Schilderij: « Famille de paysans » van Louis Le Nain (±1642), Musée du Louvre."
          },
          {
            img:"img/boeren.jpg", name:"6. Een maaltijd van het volk", fr:"le repas des paysans",
            text:"Een boerenmaaltijd bestond vaak uit <strong>brood, soep en soms wat wijn</strong>. Terwijl het hof feestte, wisten veel families niet of er de volgende dag genoeg te eten zou zijn. Juist die tegenstelling tussen arm en rijk zag Jean de La Fontaine — en verwerkte hij in zijn fabels.",
            fact:"« La raison du plus fort est toujours la meilleure » — het recht van de sterkste. La Fontaine bekritiseerde zo de macht van de rijken."
          }
        ]
      },
      {
        type:"hotspots", title:"Virtuele ontdekkingstocht door Versailles",
        intro:"Klik op de verborgen symbolen in het paleis. Vind ze allemaal om verder te gaan!",
        needed:5,
        spots:[
          {id:"sun",   label:"☀️ Het zonne-embleem", fr:"le soleil"},
          {id:"mirror",label:"🪞 Spiegelzaal", fr:"la galerie des Glaces"},
          {id:"crown", label:"👑 De kroon", fr:"la couronne"},
          {id:"garden",label:"🌳 De tuinen", fr:"les jardins"},
          {id:"key",   label:"🗝️ De sleutel van Jean", fr:"la clé"}
        ]
      },
      {
        type:"match", title:"Woordenschatspel — Frans ↔ Nederlands",
        intro:"Klik een Frans woord aan en daarna de juiste Nederlandse vertaling. Havo 3-woordenschat rond het hof.",
        leftLabel:"Français", rightLabel:"Nederlands",
        pairs:[
          {left:"le roi", right:"de koning"},
          {left:"le château", right:"het kasteel"},
          {left:"la reine", right:"de koningin"},
          {left:"le jardin", right:"de tuin"},
          {left:"la cour", right:"het hof"},
          {left:"le pouvoir", right:"de macht"}
        ]
      },
      {
        type:"quiz", title:"Historische quiz — De 17e eeuw",
        intro:"Test je kennis over het Frankrijk van de Zonnekoning.",
        questions:[
          {q:"Hoe werd Lodewijk XIV bijgenaamd?",
           options:["De Dikke Koning","De Zonnekoning (le Roi-Soleil)","De Zeekoning","De Winterkoning"], answer:1,
           explain:"'Le Roi-Soleil' — hij koos de zon als zijn symbool."},
          {q:"Welk beroemd paleis liet hij bouwen?",
           options:["Le Louvre","Versailles","Notre-Dame","Fontainebleau"], answer:1,
           explain:"Het Château de Versailles werd het centrum van zijn macht."},
          {q:"Wat betekent het Franse woord 'la cour'?",
           options:["De keuken","Het hof","De kerk","De markt"], answer:1,
           explain:"'La cour' = het hof, waar de adel rond de koning leefde."},
          {q:"Waarom zochten schrijvers de gunst van de koning?",
           options:["Voor geld en bescherming (un mécène)","Om te mogen boeren","Om soldaat te worden","Om naar zee te gaan"], answer:0,
           explain:"Een beschermheer (un mécène) gaf een schrijver geld en aanzien."}
        ],
        challenge:[
          {q:"In welk jaar verhuisde het hof officieel naar Versailles?", options:["1682","1610","1750"], answer:0, explain:"In 1682 werd Versailles het echte machtscentrum van Frankrijk."},
          {q:"Waarom verstopte La Fontaine kritiek achter dieren?", options:["Om veilig kritiek te geven zonder de koning te beledigen","Omdat hij van dieren hield","Omdat het moest van de kerk"], answer:0, explain:"Met dieren kon hij de machtigen bekritiseren zonder gevaar — slim en veilig."}
        ]
      },
      {
        type:"escape", title:"Escaperoom — De geheime boodschap in Versailles",
        story:"In de <em>galerie des Glaces</em> (spiegelzaal) heeft Jean een gecodeerde boodschap achtergelaten. Onder elk symbool ligt een <strong>cijfer</strong>, maar je krijgt het pas als je de bijbehorende vraag goed beantwoordt. <strong>Lees eerst de tekst over het hof</strong> en vorm zo de geheime jaartalcode.",
        reading:"<strong>👑 Het Frankrijk van de Zonnekoning:</strong><br><br>Koning <em>Lodewijk XIV</em> (Louis Quatorze) werd <em>le Roi-Soleil</em> — de Zonnekoning — genoemd, omdat hij de zon als zijn persoonlijke symbool koos: één zon, één koning, één macht. Hij liet het immense <em>Château de Versailles</em> bouwen. In het jaar <em>1682</em> verhuisde hij samen met het hele hof officieel naar Versailles; vanaf dat moment was het paleis het echte machtscentrum van Frankrijk. Aan het hof (<em>la cour</em>) leefde de adel in weelde. Schrijvers en kunstenaars zochten een <em>mécène</em>: een rijke beschermheer die hen geld en aanzien gaf.",
        clues:[
          {ico:"☀️", label:"Cijfer 1 — De zon", symbol:"1",
           question:"Waarom werd Lodewijk XIV 'le Roi-Soleil' (de Zonnekoning) genoemd?",
           options:["Hij woonde aan zee","Hij koos de zon als symbool van zijn macht","Hij had rood haar","Hij regeerde alleen 's zomers"], answer:1,
           explain:"Juist — één zon, één koning, één macht. Cijfer: 1."},
          {ico:"🏛️", label:"Cijfer 2 — Het paleis", symbol:"6",
           question:"Welk paleis liet de Zonnekoning bouwen als centrum van zijn macht?",
           options:["Le Louvre","Notre-Dame","Het Château de Versailles","De Sorbonne"], answer:2,
           explain:"Klopt — het Château de Versailles. Cijfer: 6."},
          {ico:"👑", label:"Cijfer 3 — Het hof", symbol:"8",
           question:"Wat betekent het Franse woord 'la cour'?",
           options:["De keuken","Het hof (de adel rond de koning)","De kerk","De markt"], answer:1,
           explain:"Precies — 'la cour' is het hof, waar de adel rond de koning leefde. Cijfer: 8."},
          {ico:"🎨", label:"Cijfer 4 — De beschermheer", symbol:"2",
           question:"Wat is een 'mécène'?",
           options:["Een soldaat","Een tuinman","Een rijke beschermheer van kunstenaars","Een kok van de koning"], answer:2,
           explain:"Juist — een mécène gaf schrijvers geld en aanzien. Cijfer: 2."}
        ],
        code:"1682", codeHint:"4 cijfers — het jaar waarin de koning en het hof officieel naar Versailles verhuisden. Lees de tekst nog eens!",
        success:"De spiegels verschuiven en onthullen Jeans boodschap: « Observe le monde, et tu comprendras les hommes. » Je bent nu Hofgeleerde!"
      }
    ]
  },

  /* ================= HOOFDSTUK 3 ================= */
  {
    id:"ch3", num:3, badge:"b3",
    title:"De werkplaats van de fabelschrijver",
    subtitle:"Wat maakt een fabel een fabel?",
    emoji:"📖",
    goal:"Herken de kenmerken van een fabel en begrijp de moraal.",
    steps:[
      {
        type:"narrative", title:"Qu'est-ce qu'une fable?",
        jean:[
          "Een <strong>fabel (une fable)</strong> is een kort verhaal, vaak met <strong>dieren die praten en denken als mensen</strong>.",
          "Elke fabel eindigt met een <strong>moraal (la morale)</strong>: een wijze les over het leven. De dieren staan symbool voor menselijke eigenschappen — de vos is sluw, de leeuw trots.",
          "Kenmerken van een fabel: ✔ kort ✔ dieren als personages ✔ een duidelijke les ✔ vaak in versvorm. Kom, we oefenen!"
        ]
      },
      {
        type:"quiz", title:"Interactieve leesopdracht — Le Corbeau et le Renard",
        intro:"Lees de samenvatting en beantwoord de vragen.\n\n« Een raaf (le corbeau) heeft een stuk kaas. Een sluwe vos (le renard) prijst zijn prachtige stem. Trots begint de raaf te zingen — en laat de kaas vallen. De vos grijpt de kaas en verdwijnt. »",
        questions:[
          {q:"Welke twee dieren spelen de hoofdrol?",
           options:["Een wolf en een lam","Een raaf en een vos","Een haas en een schildpad","Een mier en een krekel"], answer:1,
           explain:"Le corbeau (de raaf) en le renard (de vos)."},
          {q:"Hoe krijgt de vos de kaas te pakken?",
           options:["Hij steelt hem 's nachts","Door de raaf te vleien","Hij koopt hem","Hij vraagt er beleefd om"], answer:1,
           explain:"De vos vleit de raaf zodat die begint te zingen en de kaas laat vallen."},
          {q:"Wat is de moraal van deze fabel?",
           options:["Wees nooit vriendelijk","Wie vleiers gelooft, wordt bedrogen","Eet nooit kaas","Zing zo hard je kunt"], answer:1,
           explain:"« Tout flatteur vit aux dépens de celui qui l'écoute » — pas op voor vleierij."}
        ],
        challenge:[
          {q:"Voor welke eigenschap staat de vos (le renard)?", options:["Sluw (rusé)","Lui","Verdrietig"], answer:0, explain:"De vos is « rusé » — sluw en listig."},
          {q:"Wat maakt iets tot een fabel?", options:["Dieren met een karakter én een moraal","Alleen dat het rijmt","Dat het over koningen gaat"], answer:0, explain:"Een fabel = dieren als personages + een wijze les (la morale)."}
        ]
      },
      {
        type:"match", title:"Sleepopdracht — Personage koppelen aan eigenschap",
        intro:"Koppel elk fabeldier aan de eigenschap waar het symbool voor staat.",
        leftLabel:"Le personnage", rightLabel:"De eigenschap",
        pairs:[
          {left:"🦊 le renard (vos)", right:"sluw / listig"},
          {left:"🐢 la tortue (schildpad)", right:"geduldig / volhardend"},
          {left:"🦁 le lion (leeuw)", right:"trots / machtig"},
          {left:"🐜 la fourmi (mier)", right:"vlijtig / spaarzaam"},
          {left:"🦗 la cigale (krekel)", right:"zorgeloos / lui"}
        ]
      },
      {
        type:"match", title:"Moraal-matchspel",
        intro:"Koppel elke beroemde fabel aan de bijbehorende moraal.",
        leftLabel:"De fabel", rightLabel:"De moraal",
        pairs:[
          {left:"De haas en de schildpad", right:"Rustig en volhardend win je de race."},
          {left:"De raaf en de vos", right:"Pas op voor vleiers."},
          {left:"De krekel en de mier", right:"Wie niet spaart in goede tijden, lijdt in slechte."},
          {left:"De wolf en het lam", right:"De sterkste krijgt vaak zijn zin, ook onterecht."}
        ]
      },
      {
        type:"escape", title:"Escaperoom — De verdwenen moralen",
        story:"Ramp! De moralen zijn uit Jeans fabelboek verdwenen. Om ze terug te halen moet je bewijzen dat je écht begrijpt wat een fabel is. <strong>Lees de wijsheden hieronder</strong> en beantwoord elke aanwijzing goed; samen vormen de letters het sleutelwoord.",
        reading:"<strong>📖 Wat je over de fabel moet weten:</strong><br><br>Een <em>fabel</em> is een kort verhaal waarin <em>dieren praten en denken als mensen</em>. Elk dier staat symbool voor een menselijke eigenschap: de <em>vos</em> is sluw, de <em>schildpad</em> geduldig en volhardend, de <em>leeuw</em> trots en machtig, de <em>mier</em> vlijtig en spaarzaam, de <em>krekel</em> zorgeloos en lui. Elke fabel eindigt met een <em>moraal</em>: een wijze les over het leven. In « Le Corbeau et le Renard » (De raaf en de vos) vleit de sluwe vos de trotse raaf, zodat die gaat zingen en zijn kaas laat vallen. De les: pas op voor vleiers.",
        clues:[
          {ico:"🦊", label:"Letter 1 — De vos", symbol:"M",
           question:"Voor welke eigenschap staat de vos (le renard) in de fabels?",
           options:["Sluw en listig","Lui en traag","Verdrietig","Sterk en dom"], answer:0,
           explain:"Juist — de vos is sluw en listig. Letter: M."},
          {ico:"🐢", label:"Letter 2 — De schildpad", symbol:"O",
           question:"Voor welke eigenschap staat de schildpad (la tortue)?",
           options:["Snel en ongeduldig","Geduldig en volhardend","Vals","Bang"], answer:1,
           explain:"Klopt — geduldig en volhardend; zo wint zij van de haas. Letter: O."},
          {ico:"🦁", label:"Letter 3 — De raaf en de vos", symbol:"R",
           question:"Wat is de moraal van « Le Corbeau et le Renard » (de raaf en de vos)?",
           options:["Zing zo hard je kunt","Eet nooit kaas","Wie vleiers gelooft, wordt bedrogen","Wees nooit vriendelijk"], answer:2,
           explain:"Precies — pas op voor vleierij. « Tout flatteur vit aux dépens de celui qui l'écoute. » Letter: R."},
          {ico:"🐜", label:"Letter 4 — De mier", symbol:"A",
           question:"Voor welke eigenschap staat de mier (la fourmi)?",
           options:["Vlijtig en spaarzaam","Verkwistend","Trots","Zorgeloos"], answer:0,
           explain:"Juist — vlijtig en spaarzaam. Zij denkt vooruit aan de winter. Letter: A."},
          {ico:"🦗", label:"Letter 5 — Het fabelkenmerk", symbol:"L",
           question:"Wat hoort er in élke fabel te staan, naast de dieren?",
           options:["Een gevecht","Een moraal (een wijze les)","Een koning","Een liefdesverhaal"], answer:1,
           explain:"Correct — elke fabel eindigt met een moraal, een wijze les. Letter: L."}
        ],
        code:"MORAL", codeHint:"5 letters — het kernbegrip van elke fabel (denk aan het woord 'morale' zonder de laatste e).",
        success:"De moralen keren terug in het boek! Je begrijpt nu de kern van de fabel. Je bent Fabelkenner!"
      }
    ]
  },

  /* ================= HOOFDSTUK 4 ================= */
  {
    id:"ch4", num:4, badge:"b4",
    title:"Leerling van Jean",
    subtitle:"Zelf fabels analyseren",
    emoji:"🔍",
    goal:"Analyseer zelfstandig fabels en maak eigen keuzes.",
    steps:[
      {
        type:"narrative", title:"À toi de jouer!",
        jean:[
          "Nu is het jouw beurt, mon élève. Je gaat zelf fabels <strong>analyseren</strong>: wie zijn de personages, wat gebeurt er, en wat is de les?",
          "Kies een moeilijkheidsgraad die bij je past. Wees eerlijk en denk goed na — een goede leerling durft keuzes te maken."
        ]
      },
      {
        type:"quiz", title:"Analyse — La Cigale et la Fourmi (De krekel en de mier)",
        intro:"« De krekel (la cigale) zong de hele zomer. Toen de winter kwam, had zij geen eten. Zij vroeg de mier (la fourmi) om hulp. De mier, die de hele zomer had gewerkt en gespaard, weigerde: 'Je zong? Dan kun je nu dansen!' »",
        questions:[
          {q:"Wat deed de krekel de hele zomer?",
           options:["Werken en sparen","Zingen en genieten","Slapen","Reizen"], answer:1,
           explain:"La cigale zong en genoot, zonder aan de winter te denken."},
          {q:"Waarom weigert de mier te helpen?",
           options:["Ze is boos","De krekel had ook kunnen werken en sparen","Ze heeft zelf te weinig","Ze houdt niet van muziek"], answer:1,
           explain:"De mier had gewerkt; de krekel niet. Vandaar de harde les."},
          {q:"Welke moraal past het best?",
           options:["Werk hard en denk vooruit","Zing altijd","Deel nooit iets","Slaap in de winter"], answer:0,
           explain:"Wie in goede tijden vooruitdenkt, heeft het in slechte tijden beter."},
          {q:"Voor welke menselijke eigenschap staat de mier?",
           options:["Luiheid","Vlijt en verstandigheid","Gierigheid alleen","Domheid"], answer:1,
           explain:"De mier symboliseert vlijt, spaarzaamheid en vooruitzien."}
        ],
        challenge:[
          {q:"Wat betekent « la fourmi »?", options:["De mier","De krekel","De winter"], answer:0, explain:"« la fourmi » = de mier (vlijtig en spaarzaam)."},
          {q:"Waarom kiest La Fontaine dieren i.p.v. mensen?", options:["Dieren maken de les duidelijk én veilig te vertellen","Omdat mensen niet konden lezen","Omdat dieren grappiger zijn"], answer:0, explain:"Via dieren wordt de les helder en kan hij ongestraft kritiek geven."}
        ]
      },
      {
        type:"match", title:"Keuzepad — Koppel de Franse titel aan het verhaal",
        intro:"Test je kennis van La Fontaines beroemdste fabels: koppel de Franse titel aan de juiste beschrijving.",
        leftLabel:"Titre français", rightLabel:"Het verhaal",
        pairs:[
          {left:"Le Lièvre et la Tortue", right:"Een snelle haas verliest van een trage schildpad."},
          {left:"Le Loup et l'Agneau", right:"Een wolf verzint redenen om een lam op te eten."},
          {left:"Le Renard et les Raisins", right:"Een vos kan niet bij de druiven en zegt: 'ze zijn toch zuur'."},
          {left:"Le Corbeau et le Renard", right:"Een vos vleit een raaf om diens kaas te krijgen."}
        ]
      },
      {
        type:"reflect", title:"Reflectievragen",
        intro:"Denk na en schrijf jouw antwoorden op. Deze worden bewaard in je portfolio.",
        questions:[
          "Welke fabel vond jij tot nu toe het interessantst, en waarom?",
          "Welke menselijke eigenschap herken je zelf in een van de fabeldieren?",
          "Waarom gebruikt La Fontaine juist dieren en niet gewoon mensen, denk je?"
        ]
      },
      {
        type:"escape", title:"Escaperoom — De schrijverskamer van Jean",
        story:"Om Jeans persoonlijke schrijverskamer binnen te gaan, moet je vijf beroemde fabels herkennen. <strong>Lees de korte samenvattingen</strong> en beantwoord elke vraag; elk fabeldier fluistert je dan een letter.",
        reading:"<strong>🔍 Vijf beroemde fabels van La Fontaine:</strong><br><br>• <em>Le Loup et l'Agneau</em> — een sterke wolf verzint smoezen om een onschuldig lam op te eten. Les: het recht van de sterkste wint vaak, ook onterecht.<br>• <em>Le Renard et les Raisins</em> — een vos kan niet bij de druiven en zegt daarom: 'ze zijn toch zuur'.<br>• <em>Le Lièvre et la Tortue</em> — een snelle haas verliest van een trage maar volhardende schildpad.<br>• <em>La Cigale et la Fourmi</em> — de krekel zingt de hele zomer; de vlijtige mier heeft gespaard en helpt haar 's winters niet.<br>• Elke fabel is kort, heeft dieren als personages en eindigt met een <em>moraal</em>.",
        clues:[
          {ico:"🐺", label:"Letter 1 — De wolf en het lam", symbol:"F",
           question:"Wat is de les van « Le Loup et l'Agneau » (de wolf en het lam)?",
           options:["Deel altijd je eten","Het recht van de sterkste wint vaak, ook onterecht","Praat nooit met wolven","Wees snel"], answer:1,
           explain:"Juist — « La raison du plus fort est toujours la meilleure. » Letter: F."},
          {ico:"🍇", label:"Letter 2 — De vos en de druiven", symbol:"A",
           question:"Wat zegt de vos in « Le Renard et les Raisins » als hij niet bij de druiven kan?",
           options:["'Ze zijn toch zuur'","'Ik heb geen honger'","'Morgen probeer ik weer'","'Help mij!'"], answer:0,
           explain:"Klopt — hij praat zijn mislukking goed: 'ze zijn toch zuur'. Letter: A."},
          {ico:"🐇", label:"Letter 3 — De haas en de schildpad", symbol:"B",
           question:"Waarom verliest de haas van de schildpad in « Le Lièvre et la Tortue »?",
           options:["De schildpad valsspeelt","De haas is te zelfverzekerd en volhardt niet","De haas is ziek","Er is geen finish"], answer:1,
           explain:"Precies — rustig en volhardend win je de race. Letter: B."},
          {ico:"🦗", label:"Letter 4 — De krekel en de mier", symbol:"L",
           question:"Waarom helpt de mier de krekel niet in « La Cigale et la Fourmi »?",
           options:["De mier is gemeen zonder reden","De krekel zong terwijl de mier werkte en spaarde","De mier heeft zelf niets","De krekel vroeg het niet"], answer:1,
           explain:"Juist — wie niet spaart in goede tijden, lijdt in slechte. Letter: L."},
          {ico:"📖", label:"Letter 5 — Het kenmerk", symbol:"E",
           question:"Wat is een kenmerk dat ál deze fabels delen?",
           options:["Ze zijn heel lang","Ze eindigen met een moraal","Ze gaan over koningen","Ze rijmen nooit"], answer:1,
           explain:"Correct — elke fabel is kort en eindigt met een moraal. Letter: E."}
        ],
        code:"FABLE", codeHint:"5 letters — het Franse woord voor 'fabel'.",
        success:"De deur zwaait open! Je staat in Jeans schrijverskamer, klaar om zelf te schrijven. Je bent Leerling-schrijver!"
      }
    ]
  },

  /* ================= HOOFDSTUK 5 ================= */
  {
    id:"ch5", num:5, badge:"b5",
    title:"Schrijf je eigen fabel",
    subtitle:"Creatief schrijven in het Frans",
    emoji:"🖋️",
    goal:"Schrijf je eigen fabel en pas Franse taal toe.",
    steps:[
      {
        type:"narrative", title:"Deviens fabuliste!",
        jean:[
          "De grote dag is aangebroken: jij wordt <strong>fabelschrijver</strong>! Volg mijn stappenplan, gebruik de inspiratiekaarten en de Franse woordenschat.",
          "Je hoeft geen perfect Frans te schrijven — durf te proberen! Elke echte fabuliste begint met oefenen. Allez, à la plume!"
        ]
      },
      { type:"writer", title:"De werkplaats — Bouw je fabel" },
      { type:"commission", title:"La Commission Royale — ontdek hoe jouw fabel wordt beoordeeld" },
      {
        type:"escape", title:"Escaperoom — De inktpot van creativiteit",
        story:"Voordat je fabel de wereld in mag, moet de magische inktpot ontgrendeld worden. Bewijs dat je de vier bouwstenen van een goede fabel kent. <strong>Lees het stappenplan</strong> en beantwoord elke vraag; elke bouwsteen geeft je een letter.",
        reading:"<strong>🖋️ Het stappenplan van een goede fabel:</strong><br><br>1. <em>Personages</em> — kies minstens twee dieren, elk met een duidelijk karakter (bv. de sluwe vos, de trotse leeuw).<br>2. <em>Het conflict</em> — er moet een probleem ontstaan; iets gaat mis of botst.<br>3. <em>De afloop</em> — het verhaal krijgt een duidelijk einde.<br>4. <em>De moraal</em> — je sluit af met een wijze les die de lezer meeneemt.<br>Zonder deze vier onderdelen is het geen echte fabel.",
        clues:[
          {ico:"🐾", label:"Bouwsteen 1 — Personages", symbol:"H",
           question:"Wat is de eerste bouwsteen van een fabel?",
           options:["Minstens twee dieren met een karakter","Een kasteel","Een koning","Een liedje"], answer:0,
           explain:"Juist — dieren met een duidelijk karakter zijn je personages. Letter: H."},
          {ico:"⚡", label:"Bouwsteen 2 — Het conflict", symbol:"E",
           question:"Wat moet er in het midden van je fabel gebeuren?",
           options:["Iedereen gaat slapen","Er ontstaat een probleem of conflict","De dieren eten samen","Niets bijzonders"], answer:1,
           explain:"Klopt — er moet een probleem of conflict zijn. Letter: E."},
          {ico:"🎬", label:"Bouwsteen 3 — De afloop", symbol:"L",
           question:"Wat hoort er ná het conflict te komen?",
           options:["Een reclame","Een duidelijke afloop / einde","Een nieuw dier","Een titel"], answer:1,
           explain:"Precies — het verhaal krijgt een duidelijk einde. Letter: L."},
          {ico:"💡", label:"Bouwsteen 4 — De moraal", symbol:"D",
           question:"Waarmee sluit een goede fabel af?",
           options:["Met een grap","Met een moraal (een wijze les)","Met een vraag aan de koning","Met een tekening"], answer:1,
           explain:"Correct — de moraal, de wijze les, maakt de fabel af. Letter: D."}
        ],
        code:"HELD", codeHint:"4 letters — jij bent de HELD van je eigen verhaal.",
        success:"De inktpot gloeit op! Je fabel is klaar om te schitteren. Je bent nu Fabelmaker!"
      }
    ]
  },

  /* ================= HOOFDSTUK 6 ================= */
  {
    id:"ch6", num:6, badge:"b6",
    title:"Publicatie en reflectie",
    subtitle:"Presenteer en kijk terug",
    emoji:"🏛️",
    goal:"Presenteer je eindproduct en reflecteer op je leerreis.",
    steps:[
      {
        type:"narrative", title:"Le grand final",
        jean:[
          "Wat ben ik trots op je! Je hebt de hele reis afgelegd. Nu is het tijd om je werk te <strong>publiceren</strong> en terug te kijken.",
          "Kies hoe je je fabel presenteert, vul je zelfevaluatie in en verdien het eindcertificaat: <strong>Meester van de Moraal</strong>."
        ]
      },
      { type:"product", title:"Publicatie — Kies & upload je eindproduct" },
      {
        type:"reflect", title:"Zelfevaluatie & reflectie",
        intro:"Kijk eerlijk terug op je leerreis. Je antwoorden komen in je portfolio.",
        questions:[
          "Wat heb je geleerd over Jean de La Fontaine en de fabel?",
          "Waar ben je het meest trots op in je eigen fabel?",
          "Wat vond je het lastigst, en hoe heb je dat opgelost?",
          "Welk cijfer zou je jezelf geven voor deze leerreis, en waarom?"
        ]
      },
      { type:"certificate", title:"Je eindcertificaat" }
    ]
  }
];
